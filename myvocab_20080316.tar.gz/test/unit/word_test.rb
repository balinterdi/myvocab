require File.dirname(__FILE__) + '/../test_helper'

class WordTest < Test::Unit::TestCase
  fixtures :words

  # Replace this with your real tests.
  def test_truth
    assert true
  end

  def test_should_require_name
    # for that to actually work, validation
    # must be enabled in the Word model
    # (with validates_presence_of :name)
    w = Word.create(:name => nil)
    assert w.errors.on(:name)
  end

  def test_should_require_language
    # for that to actually work, validation
    # must be enabled in the Word model
    # (with validates_presence_of :name)
    w = Word.create(:lang => nil)
    assert w.errors.on(:lang)
  end

  def XXXtest_pair
    w_en = Word.find_by_name("foray")
    w_hu = Word.find_by_name("fosztogat")
    assert ( w_en.pair("hu") == w_hu )
    assert ( w_hu.pair("en") == w_en )
    w_en = Word.find_by_name("box")
    assert ( w_en.pair("hu") === nil )
  end

end

require File.dirname(__FILE__) + '/../test_helper'

class MeaningTest < Test::Unit::TestCase
  # fixtures :meanings

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end

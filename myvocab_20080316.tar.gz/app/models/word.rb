class Word < ActiveRecord::Base
  # belongs_to :meaning
  has_many :users
  has_many :words # synonims or words in other languages with the same meaning

  validates_presence_of :name, :lang

  def pair(lang)
    Word.find(:first, :conditions => { :meaning  => meaning, :lang => lang } )
  end
end

class Meaning < ActiveRecord::Base
  has_many :words

  # since Meaning is totally empty, it can only be saved
  # by setting an id to it first, like so:

  # m = Meaning.new
  # m.save - woud now raise an SQL error since there are no fields to set
  # m.id = 1
  # m.save - now this works!
  def save
    sql = ActiveRecord::Base.connection()
    meaning_id = sql.insert("INSERT INTO meanings values ( nextval('meanings_id_seq') )")
    sql.commit_db_transaction
    super.save
  end
end
